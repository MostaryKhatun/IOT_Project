/************************************************
Student Name: Mst. Mostary Khatun
Student ID: IT24612
Project Title:
IoT-Based Smart Medicine Reminder and Storage System
************************************************/

#define BLYNK_TEMPLATE_ID "TMPL6mpyGugRY"
#define BLYNK_TEMPLATE_NAME "Smart Medicine Reminder"
#define BLYNK_AUTH_TOKEN "XztUfdTTn6dN4WMVguHunnr7KHjn9r2S"

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <ESP32Servo.h>

char auth[] = BLYNK_AUTH_TOKEN;
char ssid[] = "Wokwi-GUEST";
char pass[] = "";

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

Adafruit_SSD1306 display(
  SCREEN_WIDTH,
  SCREEN_HEIGHT,
  &Wire,
  -1
);

Servo medicineServo;

#define SERVO_PIN 18
#define BUZZER_PIN 33

bool systemStarted = false;
bool reminderActive = false;

unsigned long startSimulation = 0;
unsigned long reminderStart = 0;

bool morningDone = false;
bool afternoonDone = false;
bool nightDone = false;

// =========================
// OLED
// =========================
void showOLED(String line1, String line2)
{
  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(0, 10);
  display.println(line1);

  display.setTextSize(2);
  display.setCursor(0, 30);
  display.println(line2);

  display.display();
}

// =========================
// Reminder
// =========================
void activateReminder(String period, String timeText)
{
  reminderActive = true;
  reminderStart = millis();

  medicineServo.write(90);
  tone(BUZZER_PIN, 1000);

  showOLED(period, "MEDICINE");

  Blynk.virtualWrite(V1, period + " Medicine Time");
  Blynk.virtualWrite(V2, timeText);

  Serial.println("================================");
  Serial.println(period + " MEDICINE TIME");
  Serial.println("Time : " + timeText);
  Serial.println("Servo Open");
  Serial.println("Buzzer ON");
}

// =========================
// Blynk Switch
// =========================
BLYNK_WRITE(V0)
{
  int value = param.asInt();

  if (value == 1)
  {
    systemStarted = true;
    startSimulation = millis();

    morningDone = false;
    afternoonDone = false;
    nightDone = false;

    reminderActive = false;

    Serial.println("================================");
    Serial.println("SYSTEM STARTED");
    Serial.println("10 sec = MORNING (8:00 AM)");
    Serial.println("20 sec = AFTERNOON (2:00 PM)");
    Serial.println("30 sec = NIGHT (8:00 PM)");
    Serial.println("================================");

    Blynk.virtualWrite(V1, "System Started");
    showOLED("SYSTEM", "START");
  }
  else
  {
    systemStarted = false;
    reminderActive = false;

    noTone(BUZZER_PIN);
    medicineServo.write(0);

    showOLED("SYSTEM", "OFF");

    Blynk.virtualWrite(V1, "System Stopped");
    Blynk.virtualWrite(V2, "--:--");

    Serial.println("SYSTEM STOPPED");
  }
}

// =========================
// Setup
// =========================
void setup()
{
  Serial.begin(115200);

  pinMode(BUZZER_PIN, OUTPUT);

  Wire.begin(21, 22);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C))
  {
    Serial.println("OLED Failed");
    while (1);
  }

  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);

  medicineServo.attach(SERVO_PIN);
  medicineServo.write(0);

  showOLED("Medicine Box", "READY");

  Blynk.begin(auth, ssid, pass);

  Serial.println("Waiting For Switch ON...");
}

// =========================
// Loop
// =========================
void loop()
{
  Blynk.run();

  if (!systemStarted) return;

  unsigned long elapsed = (millis() - startSimulation) / 1000;

  // MORNING (10 sec)
  if (elapsed >= 10 && !morningDone)
  {
    morningDone = true;
    activateReminder("MORNING", "08:00 AM");
  }

  // AFTERNOON (20 sec)
  if (elapsed >= 20 && !afternoonDone)
  {
    afternoonDone = true;
    activateReminder("AFTERNOON", "02:00 PM");
  }

  // NIGHT (30 sec)
  if (elapsed >= 30 && !nightDone)
  {
    nightDone = true;
    activateReminder("NIGHT", "08:00 PM");
  }

  // AUTO OFF after 5 sec
  if (reminderActive && (millis() - reminderStart > 5000))
  {
    noTone(BUZZER_PIN);
    medicineServo.write(0);

    showOLED("Medicine Box", "LOCKED");

    Blynk.virtualWrite(V1, "Medicine Taken");

    Serial.println("Buzzer OFF");
    Serial.println("Servo Close");
    Serial.println("Medicine Taken");
    Serial.println("================================");

    reminderActive = false;
  }

  // FINAL STOP
  if (morningDone && afternoonDone && nightDone && !reminderActive)
  {
    systemStarted = false;
    Blynk.virtualWrite(V0, 0);
    Blynk.virtualWrite(V1, "All Medicine Completed");

    showOLED("ALL", "DONE");

    Serial.println("ALL MEDICINE COMPLETED");
  }
}