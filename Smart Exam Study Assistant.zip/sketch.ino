/************************************************
Student Name: Mst. Mostary Khatun
Student ID: IT24612
Project Title: IoT-Based Smart Exam Study Assistant
************************************************/

#define BLYNK_TEMPLATE_ID "TMPL6CRPUpsMS"
#define BLYNK_TEMPLATE_NAME "Smart Exam Study Assistant"
#define BLYNK_AUTH_TOKEN "fm7up1E_HbRbGJX7l1OU2--dLXs_RHHj"

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

char auth[] = BLYNK_AUTH_TOKEN;
char ssid[] = "Wokwi-GUEST";
char pass[] = "";

// OLED
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

// RGB LED Pins
#define RED_LED    25
#define GREEN_LED  26
#define BLUE_LED   27

// Buzzer
#define BUZZER     33

// IMPORTANT: Common ANODE RGB LED (Wokwi default most cases)
#define LED_ON   LOW
#define LED_OFF  HIGH

bool studyStarted = false;
bool sessionCompleted = false;

unsigned long startTime = 0;
int currentState = -1;

// ===============================
// RGB CONTROL FUNCTION
// ===============================
void setRGB(bool r, bool g, bool b)
{
  digitalWrite(RED_LED,   r ? LED_ON : LED_OFF);
  digitalWrite(GREEN_LED, g ? LED_ON : LED_OFF);
  digitalWrite(BLUE_LED,  b ? LED_ON : LED_OFF);
}

// ===============================
// Blynk Button (V0)
// ===============================
BLYNK_WRITE(V0)
{
  int value = param.asInt();

  if (value == 1 && !studyStarted && !sessionCompleted)
  {
    studyStarted = true;
    startTime = millis();
    currentState = -1;

    Serial.println("Study Session Started");
  }

  if (value == 0)
  {
    sessionCompleted = false;
  }
}

// ===============================
// OLED DISPLAY
// ===============================
void showMessage(String msg)
{
  display.clearDisplay();
  display.setCursor(0, 20);
  display.println(msg);
  display.display();
}

// ===============================
// SETUP
// ===============================
void setup()
{
  Serial.begin(115200);

  Serial.println("================================");
  Serial.println("Student Name: Mst. Mostary Khatun");
  Serial.println("Student ID: IT24612");
  Serial.println("Project Title: Smart Exam Study Assistant");
  Serial.println("================================");

  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(BLUE_LED, OUTPUT);
  pinMode(BUZZER, OUTPUT);

  Wire.begin(21, 22);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C))
  {
    Serial.println("OLED Failed");
    while (1);
  }

  display.clearDisplay();
  display.setTextSize(2);
  display.setTextColor(SSD1306_WHITE);

  showMessage("READY");

  Blynk.begin(auth, ssid, pass);

  Serial.println("Connected to Blynk");

  // LED OFF INIT
  setRGB(0, 0, 0);
}

// ===============================
// LOOP
// ===============================
void loop()
{
  Blynk.run();

  if (!studyStarted) return;

  unsigned long elapsed = (millis() - startTime) / 1000;

  // =========================
  // STUDY MODE (0–10 sec)
  // =========================
  if (elapsed < 10)
  {
    if (currentState != 0)
    {
      currentState = 0;

      setRGB(0, 1, 0); // GREEN

      noTone(BUZZER);

      showMessage("STUDY");
      Blynk.virtualWrite(V1, "Study Mode");

      Serial.println("GREEN - STUDY");
    }
  }

  // =========================
  // BREAK MODE (10–15 sec)
  // =========================
  else if (elapsed < 15)
  {
    if (currentState != 1)
    {
      currentState = 1;

      setRGB(1, 1, 0); // YELLOW

      tone(BUZZER, 1000);

      showMessage("BREAK");
      Blynk.virtualWrite(V1, "Break Time");

      Serial.println("YELLOW - BREAK");
    }
  }

  // =========================
  // TIME OVER (15–20 sec)
  // =========================
  else if (elapsed < 20)
  {
    if (currentState != 2)
    {
      currentState = 2;

      setRGB(1, 0, 0); // RED

      tone(BUZZER, 2000);

      showMessage("OVER");
      Blynk.virtualWrite(V1, "Time Over");

      Serial.println("RED - OVER");
    }
  }

  // =========================
  // FINISH
  // =========================
  else
  {
    setRGB(0, 0, 0);

    noTone(BUZZER);

    showMessage("DONE");

    Blynk.virtualWrite(V1, "Finished");
    Blynk.virtualWrite(V0, 0);

    Serial.println("Session Finished");

    studyStarted = false;
    sessionCompleted = true;
    currentState = -1;
  }
}