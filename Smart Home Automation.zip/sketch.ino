/************************************************
Student Name: Mst. Mostary Khatun
Student ID: IT24612
Project Title: IoT-Based Smart Home Automation System
************************************************/

#define BLYNK_TEMPLATE_ID "TMPL6CiiHOCtf"
#define BLYNK_TEMPLATE_NAME "Smart Home Automation"
#define BLYNK_AUTH_TOKEN "0sw2ZdtcC0HzV1gZP3cJPgitCk-jqNjn"

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>
#include <ESP32Servo.h>

char auth[] = BLYNK_AUTH_TOKEN;
char ssid[] = "Wokwi-GUEST";
char pass[] = "";

#define LED_PIN 25
#define SERVO_PIN 26
#define BUZZER_PIN 27

Servo fanServo;

// =========================
// Light Control
// =========================
BLYNK_WRITE(V0)
{
  int value = param.asInt();

  digitalWrite(LED_PIN, value);

  if (value == 1)
    Serial.println("RED Light: ON");
  else
    Serial.println("RED Light: OFF");
}

// =========================
// Fan Control
// =========================
BLYNK_WRITE(V1)
{
  int value = param.asInt();

  if (value == 1)
  {
    fanServo.write(90);
    Serial.println("BLUE Fan: ON");
  }
  else
  {
    fanServo.write(0);
    Serial.println("BLUE Fan: OFF");
  }
}

// =========================
// Alarm Control (TONE BUZZER FIXED)
// =========================
BLYNK_WRITE(V2)
{
  int value = param.asInt();

  Serial.print("Alarm Value Received: ");
  Serial.println(value);

  if (value == 1)
  {
    tone(BUZZER_PIN, 1000);   // 🔊 SOUND ON
    Serial.println("YELLOW Alarm: ON");
  }
  else
  {
    noTone(BUZZER_PIN);       // 🔇 SOUND OFF
    Serial.println("YELLOW Alarm: OFF");
  }
}

// =========================
// Setup
// =========================
void setup()
{
  Serial.begin(115200);

  Serial.println("==========================================");
  Serial.println("Student Name : Mst. Mostary Khatun");
  Serial.println("Student ID   : IT24612");
  Serial.println("Project Title: IoT-Based Smart Home Automation System");
  Serial.println("==========================================");

  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  digitalWrite(LED_PIN, LOW);
  noTone(BUZZER_PIN);

  fanServo.attach(SERVO_PIN);
  fanServo.write(0);

  Serial.println("Connecting to Blynk Cloud...");

  Blynk.begin(auth, ssid, pass);

  Serial.println("ESP32 Connected Successfully!");
  Serial.println("System Ready...");
}

// =========================
// Loop
// =========================
void loop()
{
  Blynk.run();
}