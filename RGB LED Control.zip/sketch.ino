
#define BLYNK_TEMPLATE_ID "TMPL6LBCnDFV-"
#define BLYNK_TEMPLATE_NAME "RGB LED Control"
#define BLYNK_AUTH_TOKEN "rLrSjgXnc8N7lGQWaG7duFh06q_Sm6zL"

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>

char ssid[] = "Wokwi-GUEST";
char pass[] = "";

#define RED_LED    25
#define GREEN_LED  26
#define BLUE_LED   27

BlynkTimer timer;

BLYNK_WRITE(V0)
{
  digitalWrite(RED_LED, param.asInt());
}

BLYNK_WRITE(V1)
{
  digitalWrite(GREEN_LED, param.asInt());
}

BLYNK_WRITE(V2)
{
  digitalWrite(BLUE_LED, param.asInt());
}

void setup()
{
  Serial.begin(115200);

  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(BLUE_LED, OUTPUT);

  digitalWrite(RED_LED, LOW);
  digitalWrite(GREEN_LED, LOW);
  digitalWrite(BLUE_LED, LOW);

  Serial.println("Connecting to Blynk...");

  Blynk.begin(BLYNK_AUTH_TOKEN, ssid, pass);

  Serial.println("Blynk Connected!");
}

void loop()
{
  Blynk.run();
}